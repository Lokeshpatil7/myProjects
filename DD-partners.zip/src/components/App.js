import "../App.css";
import React, { Fragment, Component } from "react";
import { Route, Switch, BrowserRouter } from "react-router-dom";
import Landing from "./pages/Landing";
import Login from "./auth/Login";
import DoctorsList from "./pages/DoctorsList";
import DoctorDetail from "./pages/DoctorDetail";

function App() {
  return (
    <Fragment>
      <BrowserRouter>
        <Switch>
          <Route exact path="/landing" component={Landing} />
          <Route exact path="/" component={Login} />
          <Route exact path="/dentists" component={DoctorsList} />
          <Route exact path="/dentists/:name" component={DoctorDetail} />
        </Switch>
      </BrowserRouter>
    </Fragment>
  );
}

export default App;
