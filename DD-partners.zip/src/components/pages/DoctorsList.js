import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import apiServices from "../services/apiServices";

import Doctor from "./Doctor";
import Navbar from "../layout/Navbar";
import filterImg from "../../assets/images/filter.png";
import FilterPop from "./FilterPop";

const DoctorsList = ({ filter }) => {
  useEffect(() => {
    getDoctors();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);
  const [filterOption, setFilterOpen] = useState(true);
  const [data, setData] = useState("");
  const [doctors, setDoctors] = useState([]);
  const [doctorsList, setDoctorsList] = useState([]);
  const handleClick = () => setFilterOpen(!filterOption);

  const searchData = (childdata) => {
    setData(childdata);
    if (childdata.length) {
      const filteredData = doctors.filter((element) => {
        return element.name.toLowerCase().includes(childdata.toLowerCase());
      });
      console.log("childdata", filteredData);
      setDoctors(filteredData);
    } else {
      setDoctors(doctorsList);
    }
  };

  const getDoctors = () => {
    apiServices
      .getDoctors()
      .then((response) => {
        if (response.status === 200) {
          setDoctors(response.data.doctors);
          setDoctorsList(response.data.doctors);
        }
      })
      .catch((error) => {
        if (error.response) {
          alert(error.response.statusText);
        }
        console.log(error);
      });
  };
  return (
    <div className="DoctorList">
      <Navbar title="Doctors" bg="#e0fdf7" backBtn="/" />
      <div className="filter">
        <button type="submit" onClick={handleClick}>
          <img src={filterImg} alt="filter button" />
        </button>
      </div>
      <div className="container">
        {filterOption && <FilterPop searchData={searchData} />}
        <h4 className="result-title">
          {doctors.length === 0
            ? "There are No doctors for this search"
            : "Results showing Doctors"}
        </h4>
        <div>
          {doctors.map((doctor) => (
            <Doctor key={doctor.did} doctor={doctor} />
          ))}
        </div>
      </div>
    </div>
  );
};

DoctorsList.propTypes = {
  doctors: PropTypes.array.isRequired,
  getDoctors: PropTypes.func.isRequired,
  filter: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  doctors: state.doctor.doctors,
  filter: state.doctor.filter,
});

// export default connect(mapStateToProps, { getDoctors })(DoctorsList);
export default DoctorsList;
