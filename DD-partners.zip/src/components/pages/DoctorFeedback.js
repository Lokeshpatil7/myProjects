import React from 'react';

const DoctorFeedback = () => (
  <div className="DoctorDetail-feedback container">
    <div className="content">
      <p className="date">10 days ago</p>
      <h6>Verified User - 1</h6>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Rem expedita
        velit laudantium voluptate ullam perspiciatis mollitia! Placeat
        sapiente odit, vitae minima libero exercitationem alias non eos
        necessitatibus quam ut nisi rem, nesciunt maiores et, quisquam quaerat
        amet impedit ullam itaque magni voluptates reprehenderit debitis.
        Voluptatum ullam architecto laudantium quidem nemo minima expedita
        omnis voluptatem ea, necessitatibus quo, commodi fuga perspiciatis.
      </p>
    </div>
    <div className="content">
      <p className="date">10 days ago</p>
      <h6>Verified User - 1</h6>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Rem expedita
        velit laudantium voluptate ullam perspiciatis mollitia! Placeat
        sapiente odit, vitae minima libero exercitationem alias non eos
        necessitatibus quam ut nisi rem, nesciunt maiores et, quisquam quaerat
        amet impedit ullam itaque magni voluptates reprehenderit debitis.
        Voluptatum ullam architecto laudantium quidem nemo minima expedita
        omnis voluptatem ea, necessitatibus quo, commodi fuga perspiciatis.
      </p>
    </div>
    <div className="content">
      <p className="date">10 days ago</p>
      <h6>Verified User - 1</h6>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Rem expedita
        velit laudantium voluptate ullam perspiciatis mollitia! Placeat
        sapiente odit, vitae minima libero exercitationem alias non eos
        necessitatibus quam ut nisi rem, nesciunt maiores et, quisquam quaerat
        amet impedit ullam itaque magni voluptates reprehenderit debitis.
        Voluptatum ullam architecto laudantium quidem nemo minima expedita
        omnis voluptatem ea, necessitatibus quo, commodi fuga perspiciatis.
      </p>
    </div>
    <div className="content">
      <p className="date">10 days ago</p>
      <h6>Verified User - 1</h6>
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Rem expedita
        velit laudantium voluptate ullam perspiciatis mollitia! Placeat
        sapiente odit, vitae minima libero exercitationem alias non eos
        necessitatibus quam ut nisi rem, nesciunt maiores et, quisquam quaerat
        amet impedit ullam itaque magni voluptates reprehenderit debitis.
        Voluptatum ullam architecto laudantium quidem nemo minima expedita
        omnis voluptatem ea, necessitatibus quo, commodi fuga perspiciatis.
      </p>
    </div>
  </div>
);

export default DoctorFeedback;
