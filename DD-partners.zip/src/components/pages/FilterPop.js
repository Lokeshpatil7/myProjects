import React, { Component, useState } from "react";
import PropTypes from "prop-types";
// import { setFilter } from "../redux/actions/doctor";

function FilterPop({ searchData }) {
  const handleSearch = (e) => {
    searchData(e.target.value);
  };

  return (
    <form className="mb-5">
      <div className="form-row">
        <div className="form-group col-6 col-md-3">
          <label>Filter by Category</label>
        </div>
        {/* <div className="form-group col-6 col-md-3">
          <label>Filter by Fee</label>
          <select className="form-control form-control-lg" name="fee">
            <option> -- select an option -- </option>
            <option value={200}>$200 or less</option>
            <option value={300}>$300 or less</option>
            <option value={400}>$400 or less</option>
            <option value={500}>$500 or less</option>
            <option value={600}>$600 or less</option>
          </select>
        </div>
        <div className="form-group col-6 col-md-3">
          <label>Filter by Experience</label>
          <select className="form-control form-control-lg" name="exp">
            <option> -- select an option -- </option>
            <option value={2}>2 years or more</option>
            <option value={4}>4 years or more</option>
            <option value={6}>6 years or more</option>
            <option value={8}>8 years or more</option>
            <option value={10}>10 years or more</option>
            <option value={12}>12 years or more</option>
          </select>
        </div> */}
        {/* <div className="form-group col-6 col-md-3">
          <label>Filter by Likes</label>
          <select className="form-control form-control-lg" name="likes">
            <option> -- select an option -- </option>
            <option value={100}>100 likes or more</option>
            <option value={200}>200 likes or more</option>
            <option value={300}>300 likes or more</option>
            <option value={400}>400 likes or more</option>
            <option value={500}>500 likes or more</option>
            <option value={600}>600 likes or more</option>
          </select>
        </div> */}
      </div>
      {/* <div className="row">
        <div className="form-group col-12">
          <label>Search by name</label>
          <input
            type="text"
            name="name"
            className="form-control form-control-lg"
            placeholder="Ex: Joesph Wisoky"
            onChange={(e) => handleSearch(e)}
          />
        </div>
      </div> */}
      <div className="row">
        <div className="form-group col-12">
          <div class="input-group mb-3">
            <span class="input-group-text">
              <i class="fa fa-map-marker"></i>
            </span>
            <input
              type="text"
              class="form-control"
              placeholder="Search by Pincode"
              aria-label="Username"
              onChange={(e) => handleSearch(e)}
            />
            <span class="input-group-text">
              <i class="fa fa-search"></i>
            </span>
            <input
              type="text"
              class="form-control"
              placeholder="Search doctors"
              aria-label="Server"
              onChange={(e) => handleSearch(e)}
            />
          </div>
        </div>
      </div>
    </form>
  );
}

export default FilterPop;
