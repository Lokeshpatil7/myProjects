import React from "react";
import "../styles/DoctorDetail.scss";

const DoctorInfo = () => (
  <div className="DoctorDetail-information container">
    <div className="content">
      <h6>Education</h6>
      <ul>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
      </ul>
    </div>
    {/* <div className="content">
      <h6>Specialization</h6>
      <ul>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
      </ul>
    </div>
    <div className="content">
      <h6>Services Offered</h6>
      <ul>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
        <li>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsam
          nesciunt dolores quidem maxime dignissimos laudantium non,
          voluptatibus cum ipsa nulla, quibusdam eaque totam molestias ducimus
          dicta accusamus alias, quam velit?
        </li>
      </ul>
    </div> */}
  </div>
);

export default DoctorInfo;
