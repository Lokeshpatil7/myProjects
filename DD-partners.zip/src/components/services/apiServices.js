import Axios from "axios";
const REACT_APP_API_URL = "https://api.dentaldost.co";
const localstoredata = JSON.parse(localStorage.getItem("login"));

const headers = {
  "Content-Type": "application/json",
  Authorization:
    "bearer " + (localstoredata === null ? "a" : localstoredata.token),
};

const Login = (formInfo) => {
  return Axios.post(
    REACT_APP_API_URL + "/auth/agent/login",
    { email: formInfo.email, password: formInfo.password },
    {
      headers,
    }
  );
};

const getDoctors = () => {
  return Axios.post(
    REACT_APP_API_URL + "/agent/doctor/getDoctors",
    {},
    {
      headers,
    }
  );
};

const getDoctorDetails = (did) => {
  return Axios.post(
    REACT_APP_API_URL + "/agent/doctor/getDoctorDetails",
    { did },
    {
      headers,
    }
  );
};

const patientService = {
  Login,
  getDoctors,
  getDoctorDetails,
};

export default patientService;
